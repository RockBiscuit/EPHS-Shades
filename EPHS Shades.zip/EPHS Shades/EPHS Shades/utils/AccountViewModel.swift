//
//  AccountViewModel.swift
//  messagingApp
//
//  Created by jackson on 5/26/22.
//

import Foundation
import Firebase
import FirebaseFirestore

struct Account: Codable, Identifiable {
    var id: String?
    var profilePic: String
    var uID: String
    var email: String
}


class AccountViewModel: ObservableObject{
    
    
    @Published var accounts = [Account]()
    private let db = Firestore.firestore()
    private let user = Auth.auth().currentUser
    
    
    func fetchData(users: [String]) {
        if(user != nil){
            db.collection("users").whereField("userID", in: users).addSnapshotListener({(snapshot, error) in
                guard let documents = snapshot?.documents else {
                    print("no docs returned!")
                    return
                }
                
                
                self.accounts = documents.map({docSnapshot -> Account in
                    let data = docSnapshot.data()
                    let docId = docSnapshot.documentID
                    let image = data["profilePic"] as? String ?? "basepfp"
                    let uID = data["userID"] as? String ?? "hey"
                    let email = self.user!.email ?? "anonymous"
                    return Account(id: docId, profilePic: image, uID: uID, email: email)
                    
                    
                })
            })
        }
    }
    
    
        func createUser(){
                db.collection("users").addDocument(data: [
                    "profilePic": "basepfp",
                    "userID": "test"]){ err in
                        if let err = err {
                            print("error adding document! \(err)")
                        }
                }
        }
    func setID() {
        if(user != nil){
            db.collection("users").whereField("userID", isEqualTo: "test").getDocuments() { (snapshot, error) in
                if let error = error {
                    print("error getting document! \(error)")
                } else {
                    for document in snapshot!.documents {
                        self.db.collection("users").document(document.documentID).updateData([
                            "userID": self.user!.uid
                        ])
                    }
                    
                    
                }
            }
        }
    }

    func changeProfilePic(imageAdd: String){
        if(user != nil){
            db.collection("users").whereField("userID", isEqualTo: user!.uid).getDocuments() { (snapshot, error) in
                if let error = error {
                    print("error getting document! \(error)")
                } else {
                    for document in snapshot!.documents {
                        self.db.collection("users").document(document.documentID).updateData([
                            "profilePic": imageAdd
                        ])
                    }
                    
                    
                }
            }
            }
            
        
    }
}
