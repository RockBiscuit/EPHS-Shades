//
//  Messages.swift
//  messagingApp
//
//  Created by jackson on 5/20/22.
//

import SwiftUI


struct Messages: View {
    

    let chatroom: Chatroom
    @ObservedObject var viewModel = messagesViewModel()
    @State var messageField = ""
    @State private var copyID: Text = Text("Copy ID")
    private let pasteboard = UIPasteboard.general
    @ObservedObject var accountModel = AccountViewModel()

    init(chatroom: Chatroom){
        

        self.chatroom = chatroom
        viewModel.fetchData(docId: chatroom.id)
        accountModel.fetchData(users: chatroom.users)
    }
    var body: some View {
        VStack{
            VStack {
                Text(chatroom.title)
                    .font(.largeTitle)
                    .foregroundColor(Color("DarkText"))
                HStack {
                    Text("ID: " + String(chatroom.joinCode)).font(.subheadline)
                    Button {
                        pasteboard.string = String(chatroom.joinCode)
                        self.copyID = Text("Copied!").foregroundColor(.purple)
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            self.copyID = Text("Copy ID").foregroundColor(.white)
                        }
                    } label: {
                        copyID
                            .foregroundColor(.white)
                    }
                    

                    

                }
            }
            

            VStack{
                

                ScrollView {
                    

                    ForEach(viewModel.messages) { message in
                        if(chatroom.userId != message.uID) {
                            let pfOne = accountModel.accounts.firstIndex(where: {$0.uID == message.uID})
                            HStack{
                                Image(accountModel.accounts[pfOne ?? 0].profilePic)
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 30.0, height: 30.0, alignment: .center)
                                    .clipShape(Circle())
                                Text(message.content)
                                    .padding(8)
                                    .background(Color("LightGrey"))
                                    .cornerRadius(12)
                                Spacer()
                            }
                            .padding(.leading, 10)
                        } else {
                            let pfTwo = accountModel.accounts.firstIndex(where: {$0.uID == message.uID})
                            HStack{
                                Spacer()
                                Text(message.content)
                                    .padding(8)
                                    .background(Color("LightPurple"))
                                    .cornerRadius(12)
                                Image(accountModel.accounts[pfTwo ?? 0].profilePic)
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 30.0, height: 30.0, alignment: .center)
                                    .clipShape(Circle())
                            }
                            .padding(.trailing, 10)
                        }
                    }
                    

                }
                HStack{
                    Spacer()
                    TextField("Enter message...", text: $messageField)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button(action: {
                        if(messageField != ""){
                            viewModel.sendMessage(messageContent: messageField, docId: chatroom.id)
                            messageField = ""
                        }
                    }, label: {
                        Text("Send")
                            .foregroundColor(.purple)
                    })
                    Spacer()
                }
            }
        }
        

    }

}

struct Messages_Previews: PreviewProvider {
    static var previews: some View {
        Messages(chatroom: Chatroom(id: "10101", title: "Hello!", joinCode: 10, userId: "123", users: ["s"]))
    }
}
