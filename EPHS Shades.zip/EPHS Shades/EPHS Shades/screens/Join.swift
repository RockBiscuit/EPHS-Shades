//
//  Join.swift
//  messagingApp
//
//  Created by jackson on 5/20/22.
//

import SwiftUI
import FirebaseAuth

struct Join: View {
    
    @Binding var isOpen: Bool
    @State var showLog: Bool
    @State var joinCode = ""
    @State var newTitle = ""
    @State private var createText: String = "Enter a Chatroom Name..."
    @State private var joinText: String = "Enter a Join Code..."
    @ObservedObject var viewModel = ChatroomsViewModel()
        @ObservedObject var sessionSession = SessionStore()
        let authRef = Auth.auth()
    
    var body: some View {
        
        VStack{
                            if(showLog){
                                Button(action: {
                                    if(sessionSession.signOut()){
                                        do{
                                            try authRef.signOut()
                                        } catch{
                                            print("Error!")
                                        }
                                    } else{
                                        print("Hey")
                                    }
                                }, label: {
                                    Text("Sign Out")
                                })
                            }
            Spacer()
            Spacer()
            
            VStack{
                HStack{
                    Spacer()
                    Text("Join a chatroom")
                        .font(.title)
                        .foregroundColor(Color("LightGrey"))
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                }
                VStack{
                    HStack{
                        
                        Spacer()
                        TextField(joinText, text: $joinCode)
                            .padding(.horizontal, 32)
                            .foregroundColor(Color("LightGrey"))
                        
                        Button(action: {
                            if(joinCode == ""){
                                self.joinText = "Please Enter a Join Code"
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    self.joinText = "Enter a Join Code..."
                                }
                            } else {
                                viewModel.joinChatroom(code: joinCode) {
                                    self.isOpen = false
                                }
                            }
                        }, label: {
                            Text("Join")
                        })
                        Spacer()
                        Spacer()
                        Spacer()
                        Spacer()
                        Spacer()
                    }
                    Rectangle()
                        .fill(Color("LightGrey"))
                        .frame(height: 3)
                        .cornerRadius(15.0)
                        .padding(.horizontal, 40)
                        .padding(.bottom, 40)
                }
            }
            Spacer()
            
            HStack{
                Spacer()
                Text("Create a Chatroom")
                    .font(.title)
                    .foregroundColor(Color("LightGrey"))
                Spacer()
                Spacer()
                Spacer()
                Spacer()
            }
            VStack{
                HStack{
                    Spacer()
                    TextField(createText, text: $newTitle)
                        .padding(.horizontal, 32)
                        .foregroundColor(Color("LightGrey"))
                    
                    Button(action: {
                        if(newTitle == ""){
                            self.createText = "Please Enter a Title"
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                self.createText = "Enter a Chatroom Name..."
                            }
                        } else {
                            viewModel.createChatroom(title: newTitle) {
                                self.isOpen = false
                            }
                        }
                    }, label: {
                        Text("Create")
                    })
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                }
                Rectangle()
                    .fill(Color("LightGrey"))
                    .frame(height: 3)
                    .cornerRadius(15.0)
                    .padding(.horizontal, 40)
                    .padding(.bottom, 40)
            }
            Spacer()
            Spacer()
            
        }
        
    }
}

//
//struct Join_Previews: PreviewProvider {
//    static var previews: some View {
//        Join(isOpen: .constant(true))
//    }
//}
