//
//  accountView.swift
//  messagingApp
//
//  Created by jackson on 5/26/22.
//

import SwiftUI
import FirebaseAuth


struct accountView: View {
    @ObservedObject var accountModel = AccountViewModel()
    @State var picField = ""
    @State var changeEmailField = ""
    @State var isOpen = false
    @ObservedObject var sessionSession = SessionStore()
    let authRef = Auth.auth()
    private let user = Auth.auth().currentUser
    init(){
        if (user != nil){
            accountModel.setID()
            accountModel.fetchData(users: [user!.uid])
            print("testing")
            
        }
    }
    var body: some View {
        
        
        VStack{
            Text("This Is Your Account!")
            Text("More Stuff Will Be Coming Soon")

            Button(action: {
                if(sessionSession.signOut()){
                    do{
                        try authRef.signOut()
                    } catch{
                        print("Error!")
                    }
                } else{
                    print("Hey")
                }
            }, label: {
                Text("Sign Out")
            })
//            if (user != nil){
//                Image(accountModel.accounts[0].profilePic)
//                    .resizable()
//                    .aspectRatio(contentMode: .fill)
//                    .frame(width: 250.0, height: 250.0, alignment: .center)
//                    .clipShape(Circle())
//            }

//            HStack{
//                if (user != nil){
//                    Text("Email: " + (user?.email)!)
//                }
//                Button(action: {
//                    isOpen = true
//                }, label: {
//                    Text("Change")
//                        .foregroundColor(.purple)
//                })
//            }
//            HStack{
//                Spacer()
//                TextField("Enter picture name...", text: $picField)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                Button(action: {
//                    if(picField != ""){
//                        accountModel.changeProfilePic(imageAdd: picField)
//                        picField = ""
//                    }
//                }, label: {
//                    Text("Send")
//                        .foregroundColor(.purple)
//                })
//                Spacer()
//            }
        }.sheet(isPresented: $isOpen) {
            VStack{
                Text("Email Reset")
                HStack{
                    TextField("Enter a new Email...", text: $changeEmailField )
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button(action: {
                        if(changeEmailField != ""){
                            user?.updateEmail(to: changeEmailField)
                            changeEmailField = ""
                            
                        }
                    }, label: {
                        Text("Enter")
                            .foregroundColor(.purple)
                    })
                }
            }
        }
    }
}

struct accountView_Previews: PreviewProvider {
    static var previews: some View {
        accountView()
    }
}
