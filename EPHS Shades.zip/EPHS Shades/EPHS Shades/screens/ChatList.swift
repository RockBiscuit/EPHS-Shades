//
//  ChatList.swift
//  messagingApp
//
//  Created by jackson on 5/17/22.
//

import SwiftUI
import FirebaseAuth

struct ChatList: View {
    
    
    @ObservedObject var viewModel = ChatroomsViewModel()
    @ObservedObject var chatModel = messagesViewModel()
    @ObservedObject var accountModel = AccountViewModel()
    @ObservedObject var sessionSession = SessionStore()
    let authRef = Auth.auth()
    @State var joinModal = false
    private let user = Auth.auth().currentUser

    init(){
        if (user != nil){
        viewModel.fetchData()
        accountModel.setID()
    }
    }
    
    
    var body: some View {
        
        ZStack{
            Color("Background")
                .ignoresSafeArea()
            NavigationView{
                List{
                    ForEach(viewModel.chatrooms) { chatroom in
                        NavigationLink(destination: Messages(chatroom: chatroom)){

                            HStack{
                                VStack{
                                    Text(chatroom.title)
                                        .font(.system(size: 25.0))
                                        .fontWeight(.heavy)
                                        .foregroundColor(Color("LightText"))
                                }
                                Spacer()
                            }
                        }
                        
                        .navigationBarItems(leading: Text("Chatrooms")
                                                .foregroundColor(Color("DarkText"))
                                                .font(.system(size: 35.0))
                                                .fontWeight(.heavy),
                                            trailing:
                                                Button(action: {
                            self.joinModal = true
                            
                        }, label: {
                            HStack {
                                Text("New Room")
                                    .fontWeight(.heavy)
                                    .font(.title3)
                                    .foregroundStyle(
                                        .linearGradient(
                                            colors: [Color("LightText"), Color("DarkText")],
                                            startPoint: .top,
                                            endPoint: .bottom
                                        )
                                    )
                            }
                        })
                        )
                        .sheet(isPresented: $joinModal, content: {
                            Join(isOpen: $joinModal, showLog: false)
                        })
                        
                        
                    }.onDelete(perform: self.deleteRow)
                    
                    
                }.foregroundColor(Color("LightText"))
                
                
            }.padding(.bottom, -50)
        
            if(viewModel.chatrooms.count == 0) {
                Join(isOpen: $joinModal, showLog: true)
            }
        }
    }
    private func deleteRow(at indexSet: IndexSet) {
        self.viewModel.chatrooms.remove(atOffsets: indexSet)
    }
    
    
}

struct ChatList_Previews: PreviewProvider {
    static var previews: some View {
        ChatList()
    }
}
