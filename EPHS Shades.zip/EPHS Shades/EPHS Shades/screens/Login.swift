//
//  Login.swift
//  Shades
//
//  Created by קคאՇ๏ภ / 5.19.22
//

import SwiftUI

extension UIScreen{
    static let screenWidth = UIScreen.main.bounds.size.width
    static let screenHeight = UIScreen.main.bounds.size.height
    static let screenSize = UIScreen.main.bounds.size
}


struct Login: View {
    @Environment(\.colorScheme) var colorScheme
    @State var email = ""
    @State var password = ""
    @State var showPass: Bool = false
    @State private var showLog : Bool = false
    @ObservedObject var accountModel = AccountViewModel()
    @ObservedObject var sessionSession = SessionStore()
    init() {
        sessionSession.listen()
    }
    var body: some View {
        ZStack {
            Color("Background")
                .ignoresSafeArea()
            
            VStack {
                //UPPER
                Image("topBar")
                    .resizable()
                
                //MIDDLE
                
                VStack {
                    
                    //Spacer()
                    HStack {
                        Spacer()
                        
                        Text("Welcome Back,   ")
                            .fontWeight(.bold)
                        
                            .font(.largeTitle)
                            .multilineTextAlignment(.leading)
                        //.padding(-5)
                            .background(Color("Background"))
                            .foregroundStyle(
                                .linearGradient(
                                    colors: [Color("LightPurple"), Color("DarkPurple")],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                        Spacer()
                        Spacer()
                        Spacer()
                    }.padding(.top, -50)
                    HStack {
                        Spacer()
                        Text("Login To Continue   ")
                            .fontWeight(.bold)
                        
                            .font(.headline)
                            .multilineTextAlignment(.leading)
                        //.padding()
                            .background(Color("Background"))
                            .foregroundColor(Color("LightGrey"))
                        
                        Spacer()
                        Spacer()
                        Spacer()
                        Spacer()
                        Spacer()
                    }
                }
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                
                VStack{
                    
                    VStack{
                        Spacer()
                        HStack{
                            Spacer()
                            Text("Email             ")
                                .foregroundColor(Color("LightGrey"))
                                .fontWeight(.heavy)
                                .font(.title)
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            
                            
                        }
                        HStack{
                            
                            Spacer()
                            TextField("Example@gmail.com", text: $email)
                                .padding(.horizontal, 32)
                                .foregroundColor(Color("LightGrey"))
                            
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            
                        }
                        
                        Rectangle()
                            .fill(Color("LightGrey"))
                            .frame(height: 3)
                            .cornerRadius(15.0)
                            .padding(.horizontal, 40)
                            .padding(.bottom, 40)
                        Spacer()
                        Spacer()
                        HStack{
                            Spacer()
                            Text("Password  ")
                                .foregroundColor(Color("LightGrey"))
                                .fontWeight(.heavy)
                                .font(.title)
                                .padding(.bottom, -2)
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            
                        }
                        HStack{
                            Spacer()
                            if(showPass){
                                TextField("Password Showing", text: $password)
                                    .padding(.horizontal, 32)
                                    .padding(.top, 5)
                                    .foregroundColor(Color("LightGrey"))
                                
                            }else {
                                SecureField("Password Hidden", text: $password)
                                    .padding(.horizontal, 32)
                                    .padding(.top, 5)
                                    .foregroundColor(Color("LightGrey"))
                                
                            }
                            Button (action: {
                                showPass.toggle()
                            }, label: {
                                
                                Image(systemName: "eye")
                                    .font(.title)
                            })
                                .padding(.trailing, 40)
                                .padding(.bottom, 3)
                                .foregroundColor(Color("LightGrey"))
                            
                        }
                        Rectangle()
                            .fill(Color("LightGrey"))
                            .frame(height: 3)
                            .cornerRadius(15.0)
                            .edgesIgnoringSafeArea(.horizontal)
                            .padding(.horizontal, 40)
                        
                        Spacer()
                        
                    }

                    
                }
                
            
                
                
                //LOWER
                VStack{
                    
                    ZStack{
                        
                        Image("Bottom")
                            .resizable()
                        
                        ZStack {
                            VStack {
                                Button(action: {
                                    sessionSession.signIn(email: email, password: password)
                                    
                                    
                                }, label: {
                                    HStack {
                                        Text("Login")
                                            .fontWeight(.heavy)
                                            .font(.title3)
                                            .foregroundStyle(
                                                .linearGradient(
                                                    colors: [Color("LightText"), Color("DarkText")],
                                                    startPoint: .top,
                                                    endPoint: .bottom
                                                )
                                            )
                                    }
                                    .frame(minWidth: 0, maxWidth: UIScreen.screenWidth-200)
                                    .padding()
                                    .background(Color("Background"))
                                    .cornerRadius(13)
                                    .padding(-5)
                                })
                                HStack {
                                    Text("New User?")
                                        .fontWeight(.semibold)
                                        .foregroundColor(Color("Color-1"))
                                    
                                        .font(.headline)
                                    Button (action: {
                                        showLog.toggle()
                                    }, label: {
                                        HStack {
                                            Text("Sign Up")
                                                .font(.body)
                                                .fontWeight(.bold)
                                                .foregroundColor(Color("Color-2"))
                                        }
                                        
                                        
                                    })
                                }
                            }.offset(y: 35)
                        }
                        
                    }
                }
                
            }.ignoresSafeArea()
        }        .fullScreenCover(isPresented: $showLog, content: { signUp(showLog: $showLog)
        })
    }
    
    
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
        
    }
}
