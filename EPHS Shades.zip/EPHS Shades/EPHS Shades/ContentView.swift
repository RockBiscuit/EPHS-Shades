//
//  ContentView.swift
//  messagingApp
//
//  Created by jackson on 5/13/22.
//

import SwiftUI

struct ContentView: View {
    
    
    @ObservedObject var sessionStore = SessionStore()
    @ObservedObject var accountModel = AccountViewModel()

    
    init(){
        sessionStore.listen()
    }
    
    
    var body: some View {
        TabView{
            ChatList()
                .tabItem{
                    Label("Messages", systemImage: "message")
                }
            accountView()
                .tabItem{
                    Label("Account", systemImage: "person")

                }
        }.accentColor(Color("LightPurple"))

            .fullScreenCover(isPresented: $sessionStore.isAnon, content: { Login()
            })

//        feef()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
